// Import the MongoDB driver
const MongoClient = require("mongodb").MongoClient;
const username = process.env.MongoAtlasUser;
const password = process.env.MongoAtlasPassword;

const MONGODB_URI =
  "mongodb+srv://username:password@awsTest.hsafn.mongodb.net/sample_mflix?retryWrites=true&w=majority";

const connectionParams = {
  useNewUrlParser: true,
  useUnifiedTopology: true,
};

exports.handler = async (event, context) => {
  const client = await new MongoClient(MONGODB_URI, connectionParams);
  await client.connect();

  const cursor = client
    .db("sample_mflix")
    .collection("movies")
    .find()
    .limit(10);

  const results = await cursor.toArray();
  console.log(results);

  const response = {
    statusCode: 200,
    body: JSON.stringify(results),
  };

  return response;
};
